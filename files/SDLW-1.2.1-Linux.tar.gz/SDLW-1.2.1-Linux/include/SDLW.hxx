/*	SDLW.hxx -- common header for the SDLWrapper
 *
 *		Copyright © 2012-NOW Srikanth Anantharam
 *		Created 22-Oct-2012 by Srikanth Anantharam
 */

#ifndef SDLW_H_
#define SDLW_H_

#include <stdio.h>
#include <stdarg.h>
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include "SDL_gfxPrimitives.h"

// Define colors here
#if defined(_WIN32)
#define COLOR_BLACK {0, 0, 0, 0}
#define COLOR_WHITE {255, 255, 255, 0}
#define COLOR_RED {255, 0, 0, 0}
#define COLOR_GREEN {0, 255, 0, 0}
#define COLOR_BLUE {0, 0, 255, 0}
#define COLOR_MAGENTA {255, 0, 255, 0}
#else
#define COLOR_BLACK (SDL_Color) {0, 0, 0, 0}
#define COLOR_WHITE (SDL_Color) {255, 255, 255, 0}
#define COLOR_RED (SDL_Color) {255, 0, 0, 0}
#define COLOR_GREEN (SDL_Color) {0, 255, 0, 0}
#define COLOR_BLUE (SDL_Color) {0, 0, 255, 0}
#define COLOR_MAGENTA (SDL_Color) {255, 0, 255, 0}
#endif

// Define the fonts here
#define FONT_INCONSOLATA "../data/fonts/Inconsolata-Regular.ttf"
#define FONT_INCONSOLATA_BOLD "../data/fonts/Inconsolata-Bold.ttf"

// Intializes the SDL, its subsystems and sets the display mode
// defaults to native resolution
SDL_Surface * sdlInit( int displayWidth = 0,
					   int displayHeight = 0,
					   int displayDepth = 0,
                       Uint32 sdlInitFlags = SDL_INIT_VIDEO,
                       Uint32 displayModeFlags = SDL_HWSURFACE );

// Frees SDL and its subsystems
void sdlQuit( void );

// Forcefully quit after freeing SDL (atexit is evil)
inline void sdlExit( int retVal ) {
	sdlQuit();
	exit( retVal );
}

// Updates the screen SDL_Surface by flipping the back buffer
inline void sdlFlip( void ) {
	if ( SDL_Flip( SDL_GetVideoSurface() ) < 0 ) {
		fprintf( stderr,
				 "sdlFlip:: error using SDL_Flip(): %s\n",
				 SDL_GetError() );
		sdlExit( EXIT_FAILURE );
	}
	return;
}

// Loads image from file in the current pixel format (Uses SDL_image library)
SDL_Surface * imageLoad( const char * imagePath );

// Allocates a SDL_Surface of the specified pixel format
// By default create a SDL_SWSURFACE
SDL_Surface * imageCreate( int imageWidth,
						   int imageHeight,
						   int imageDepth,
						   Uint32 imageFormatFlags = SDL_SWSURFACE );

// Allocates a SDL_Surface of the specified pixel format from the provided pixel data
SDL_Surface * imageCreateFrom( void * imagePixels,
							   int imageWidth,
							   int imageHeight,
							   int imageDepth );

// Return a cropped portion of the SDL_Surface as specified
SDL_Surface * imageCrop( SDL_Surface * inputSurface,
						 int x,
						 int y,
						 int imageWidth,
						 int imageHeight,
                         Uint32 imageFormatFlags = 0 );

// Save the SDL_Surface in BMP format with the filename specified
void imageSaveBMP( SDL_Surface * inputSurface,
				   const char * imagePath );

// Locks a SDL_Surface if it needs to be locked before accessing pixels and format members of SDL_Surface
void imageLock( SDL_Surface * inputSurface );

// Unlocks a SDL_Surface if it has been locked before
inline void imageUnlock( SDL_Surface * inputSurface ) {
	SDL_UnlockSurface( inputSurface );
    return;
}

// Blits source SDL_Surface onto dest SDL_Surface at the specified coordinates
inline void imageBlit( SDL_Surface * srcSurface,
					   int x,
					   int y,
					   SDL_Surface * destSurface ) {
	SDL_Rect offset;
	offset.x = x;
	offset.y = y;
	offset.w = srcSurface->w;
	offset.h = srcSurface->h;
	if ( SDL_BlitSurface( srcSurface,
						  NULL,
						  destSurface,
						  &offset ) < 0 ) {
		fprintf( stderr,
				 "imageBlit:: error: using SDL_BlitSurface(): %s\n",
				 SDL_GetError() );
		sdlExit( EXIT_FAILURE );
	}
	return;
}

// Displays the SDL_Surface at the specified coordinates
inline void imageDisplay( SDL_Surface * inputSurface,
						  int x = 0,
						  int y = 0 ) {
    if ( inputSurface != NULL ) {
    	SDL_Rect offset;
    	offset.x = x;
    	offset.y = y;
    	offset.w = inputSurface->w;
    	offset.h = inputSurface->h;

    	if ( SDL_BlitSurface( inputSurface,
    						  NULL,
    						  SDL_GetVideoSurface(),
    						  &offset ) < 0 ) {
    		fprintf( stderr,
    				 "imageDisplay:: error: using SDL_BlitSurface(): %s\n",
                     SDL_GetError() );
    		sdlExit( EXIT_FAILURE );
    	}
    	sdlFlip();
	}
	return;
}

// Releases the SDL_Surface deallocating the allocated memory
inline void imageFree( SDL_Surface * inputSurface ) {
	SDL_FreeSurface( inputSurface );
	return;
}

// Loads font from the file with specified size
TTF_Font * fontLoad( const char * fontPath,
					 int fontSize );

// Releases the font from memory
inline void fontFree( TTF_Font * font ) {
	TTF_CloseFont( font );
    return;
}

// Blits the text using the specified font onto the dest SDL_Surface at the specified coordinates
void textBlit( TTF_Font * font,
			   int x,
			   int y,
			   SDL_Surface * destSurface,
			   SDL_Color fontColor,
			   const char * textFormat,
			   ... );

// Display the text using the specified font at the specified coordinates
void textDisplay( TTF_Font * font,
				  int x,
				  int y,
				  SDL_Color fontColor,
				  const char * textFormat,
				  ... );

// Create a YUV overlay in the specified width, height and pixel format
SDL_Overlay * overlayCreate( int overlayWidth,
							 int overlayHeight,
							 Uint32 overlayFormat = SDL_YUY2_OVERLAY );

// Display the YUV overlay
void overlayDisplay( SDL_Overlay * overlay,
					 int x,
					 int y );

// Unload the YUV overlay
inline void overlayFree( SDL_Overlay * overlay ) {
	SDL_FreeYUVOverlay( overlay );
    return;
}

#endif /* SDLW_H_ */
