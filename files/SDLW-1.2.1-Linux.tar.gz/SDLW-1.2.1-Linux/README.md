# SDL Wrapper

## Introduction
SDL (Simple DirectMedia Library) is a cross-platform software library popularly used in multimedia applications and games development. I stumbled upon SDL while researching for a high-performance library to use in embedded software development. SDLW (SDL Wrapper) provides a thin wrapper around SDL along with support for error handling and is written in C/C++. SDLW is useful for basic image processing tasks and more. The download includes:
* the Linux static library
* the development header
* few demo applications
* source code for the demo applications

The code is very much self-explanatory.

## Demonstration Applications
There are 6 demonstration applications available with the download. They demonstrate the following use cases.

### imageDemo
* display initialization
* loading an image file from the specified path
* displaying the image

### textDemo
* displaying any text at the desired display co-ordinates

### imageRGBtoGrayDemo
* image pixel manipulation

### imageTemplateMatchingDemo
* template matching using a simple algorithm: SAD (sum of absolute differences)

### keyboardEventDemo
* capture key press event
* key press event handling

### mouseEventDemo
* capture mouse click event
* obtain mouse click co-ordinates
