/*	imageDemo.cxx -- imageDemo example
 *	This example shows how to read and display an image file
 *
 *		Copyright © 2012-NOW Srikanth Anantharam
 *		Created 2012 by Srikanth Anantharam
 *		Modified 02-Feb-2016 by Srikanth Anantharam
 */

#include "SDLW.hxx"

int main(int argc, char * args[]) {
	// Flag that controls when the app exits
	int quitApp = 0;
	// Structure that holds the event data from keyboard, mouse and window events
	SDL_Event eventData;

	// Initialize the display by providing the width, the height, and the bit depth
    sdlInit(640, 480, 0);

	// This is how you can load an image
	SDL_Surface *image = imageLoad("../data/images/colours.png");

	// This is how you can display an image
	imageDisplay(image);

	// The main loop continues to execute as long as quitApp is equal to 0
    while (quitApp == 0) {
    	// Catch keyboard, mouse, and window events
        while ( SDL_PollEvent( &eventData ) ) {
            switch ( eventData.type ) {
                case ( SDL_QUIT ):
                	// Exit from app if the user closes the window
                    quitApp = 1;
                    break;
                case ( SDL_KEYDOWN ):
					switch ( eventData.key.keysym.sym ) {
						case ( SDLK_ESCAPE ):
                			// Exit from app if the user presses the Escape button on the keyboard
							quitApp = 1;
							break;
						case ( SDLK_q ):
	                		// Exit from app if the user presses the "q" button on the keyboard
							quitApp = 1;
							break;
						default:
							break;
					}
                    break;
                default:
                    break;
            }
        }
    }

    // Always unload any image that you create
    imageFree(image);

    // Quit SDL
    sdlQuit();

	// Dont forget to return 0 as we have sucessfully executed
    return (0);
}
