/*	keyboardEventDemo.cxx -- keyboardEventDemo example
 *	This example demonstrates keyboard event handling
 *
 *		Copyright © 2012-NOW Srikanth Anantharam
 *		Created 2012 by Srikanth Anantharam
 *		Modified 02-Feb-2016 by Srikanth Anantharam
 */

#include "SDLW.hxx"

// You should always define main like this
int main(int argc, char * args[]) {
	// Flag that controls when the app exits
	int quitApp = 0;
	// Structure that holds the data from keyboard, mouse and window events
	SDL_Event eventData;
	char ch[] = "Entered key is:   ";

	// Initialize the display by providing the width, the height, and the bit depth of the window
	// Otherwise you can also leave it out by just calling initDisplay();
    sdlInit(0, 0, 0);
	SDL_EnableUNICODE(1);

    // Load font displaying text specifying the font size
    TTF_Font * font = fontLoad(FONT_INCONSOLATA_BOLD, 20);

	// Display text at coordinates x=0, y=0
	textDisplay(font, 0, 0, COLOR_MAGENTA, "Press 'ESC' or 'q' to quit.");
	textDisplay(font, 0, 40, COLOR_MAGENTA, "Press 'd' to display hello world.");

	// The main loop continues to execute as long as quitApp is equal to 0
    while (quitApp == 0) {
    	// Catch keyboard, mouse, and window events
        while ( SDL_PollEvent( &eventData ) ) {
            switch ( eventData.type ) {
                case ( SDL_QUIT ):
                	// Exit from app if the user closes the window
                    quitApp = 1;
                    break;
                case ( SDL_KEYDOWN ):
					textDisplay(font, 0, 120, COLOR_BLACK, ch);
					ch[16] = eventData.key.keysym.unicode & 0x7F;
					textDisplay(font, 0, 120, COLOR_MAGENTA, ch);
					switch ( eventData.key.keysym.sym ) {
						case ( SDLK_ESCAPE ):
                			// Exit from app if the user presses the Escape button on the keyboard
							quitApp = 1;
							break;
						case ( SDLK_q ):
	                		// Exit from app if the user presses the "q" button on the keyboard
							quitApp = 1;
							break;
						case ( SDLK_d ):
	                		// Display hello world if the user presses the "d" button on the keyboard
	                		textDisplay(font, 0, 80, COLOR_MAGENTA, "Hello World!");
							break;
						default:
							break;
					}
                    break;
                default:
                    break;
            }
        }
    }

    // Always unload fonts that you have loaded
    fontFree(font);

    // Quit SDL
    sdlQuit();

	// Dont forget to return 0 as we have sucessfully executed
    return (0);
}
