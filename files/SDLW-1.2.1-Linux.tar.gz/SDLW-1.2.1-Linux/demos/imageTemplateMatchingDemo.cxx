/*	imageTemplateMatchingDemo.cxx -- imageTemplateMatchingDemo example
 *	This example demonstrates pixel level image manipulation
 *
 *		Copyright © 2012-NOW Srikanth Anantharam
 *		Created 2012 by Srikanth Anantharam
 *		Modified 02-Feb-2016 by Srikanth Anantharam
 */

#include "SDLW.hxx"
#include <stdlib.h>

// Convert RGB image into Gray
void imageRGBtoGray(unsigned char * outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight);

// Convert RGBA image into Gray
void imageRGBAtoGray(unsigned char * outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight);

// Match Template using SAD
void imageTemplateMatchingSAD(int * matchValue, int * matchX, int * matchY,
					   		  unsigned char * inputPixels, int inputWidth, int inputHeight,
					   		  unsigned char * templatePixels, int templateWidth, int templateHeight);

// You should always define main like this
int main(int argc, char * args[]) {
	// Flag that controls when the app exits
	int quitApp = 0;
	// Structure that holds the data from keyboard, mouse and window events
	SDL_Event eventData;
	SDL_Surface * image = NULL;
	int matchValue = 0, matchX = 0, matchY = 0;

	// Initialize the display by providing the width, the height, and the bit depth of the window
	// Otherwise you can also leave it out by just calling initDisplay();
    sdlInit(0, 0, 0);

    // Load font displaying text
    TTF_Font * font = fontLoad(FONT_INCONSOLATA_BOLD, 20);

	// Load the input image
	image = imageLoad("../data/images/bearing.jpg");
	SDL_Surface *inputImage = imageCreate(image->w, image->h, 8);
	// Lock the input image for pixels access
	imageLock(inputImage);
	imageRGBtoGray((unsigned char *)inputImage->pixels, (unsigned char *)image->pixels, image->w, image->h);
	imageFree(image);
	// Unlock input image
	imageUnlock(inputImage);

	// Load the template image
	image = imageLoad("../data/images/bearing_template.jpg");
	SDL_Surface *templateImage = imageCreate(image->w, image->h, 8);
	// Lock the template image for pixels access
	imageLock(templateImage);
	imageRGBtoGray((unsigned char *)templateImage->pixels, (unsigned char *)image->pixels, image->w, image->h);
	imageFree(image);

	// Unlock template image
	imageUnlock(templateImage);

	// Display Input Image
	imageDisplay(inputImage, 0, 0);
	textDisplay(font, 0, inputImage->h, COLOR_MAGENTA, "Input Image (%d x %d)", inputImage->w, inputImage->h);

	// Display Template Image
	imageDisplay(templateImage, inputImage->w + 20, 0);
	textDisplay(font, inputImage->w + 20, templateImage->h, COLOR_MAGENTA, "Template Image, (%d x %d)", templateImage->w, templateImage->h);
	// Update the display to reflect the changes on the screen
	sdlFlip();

	// Lock the images before pixels access
	imageLock(inputImage);
	imageLock(templateImage);

	// Search for the matching template in the input image
	imageTemplateMatchingSAD(&matchValue, &matchX, &matchY,
					  		 (unsigned char *)inputImage->pixels, inputImage->w, inputImage->h,
					  		 (unsigned char *)templateImage->pixels, templateImage->w, templateImage->h);

	// Unlock the images
	imageUnlock(inputImage);
	imageUnlock(templateImage);

	// You can also display printf style using showText
	textDisplay(font, inputImage->w + 20, templateImage->h + 20, COLOR_MAGENTA, "Match Coordinates: (%d, %d)", matchX, matchY);
	textDisplay(font, inputImage->w + 20, templateImage->h + 40, COLOR_MAGENTA, "Match Value: [%d]", matchValue);

	// Draw a rectangle on the screen indication the match coordinates
	rectangleRGBA(SDL_GetVideoSurface(), matchX, matchY, matchX+templateImage->w, matchY+templateImage->h, 255, 0, 0, 255);
	rectangleRGBA(SDL_GetVideoSurface(), matchX-1, matchY-1, matchX+templateImage->w+1, matchY+templateImage->h+1, 255, 0, 0, 255);
	// Update the display to reflect the changes on the screen
	sdlFlip();

	// The main loop continues to execute as long as quitApp is equal to 0
    while (quitApp == 0) {
    	// Catch keyboard, mouse, and window events
        while ( SDL_PollEvent( &eventData ) ) {
            switch ( eventData.type ) {
                case ( SDL_QUIT ):
                	// Exit from app if the user closes the window
                    quitApp = 1;
                    break;
                case ( SDL_KEYDOWN ):
					switch ( eventData.key.keysym.sym ) {
						case ( SDLK_ESCAPE ):
                			// Exit from app if the user presses the Escape button on the keyboard
							quitApp = 1;
							break;
						case ( SDLK_q ):
	                		// Exit from app if the user presses the "q" button on the keyboard
							quitApp = 1;
							break;
						default:
							break;
					}
                    break;
                default:
                    break;
            }
        }
    }

    // Always unload any image that you create
    imageFree(inputImage);
    imageFree(templateImage);

    // Always unload fonts that you have loaded
    fontFree(font);

    // Quit SDL
    sdlQuit();

	// Dont forget to return 0 as we have sucessfully executed
    return (0);
}

// Convert RGB image into Gray
void imageRGBtoGray(unsigned char *outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight) {
	int i, j, pixelIndex;
	unsigned char r, g, b, gray;
	for ( j=0; j<imageHeight; ++j ) {
		for ( i=0; i<imageWidth; ++i ) {
			pixelIndex = i + j * imageWidth;
			r = inputPixels[pixelIndex * 3];
			g = inputPixels[pixelIndex * 3 + 1];
			b = inputPixels[pixelIndex * 3 + 2];
			gray = ( r * (int) (0.299f * 256) + g * (int) (0.587f * 256) + b * (int) (0.114f * 256) ) / 256;
			outputPixels[pixelIndex] = gray;
		}
	}
}

// Convert RGBA image into Gray
void imageRGBAtoGray(unsigned char *outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight) {
	int i, j, pixelIndex;
	unsigned char r, g, b, gray;
	for ( j=0; j<imageHeight; ++j ) {
		for ( i=0; i<imageWidth; ++i ) {
			pixelIndex = i + j * imageWidth;
			r = inputPixels[pixelIndex * 4];
			g = inputPixels[pixelIndex * 4 + 1];
			b = inputPixels[pixelIndex * 4 + 2];
			gray = ( r * (int) (0.299f * 256) + g * (int) (0.587f * 256) + b * (int) (0.114f * 256) ) / 256;
			outputPixels[pixelIndex] = gray;
		}
	}
}

// Match Template using SAD
void imageTemplateMatchingSAD(int *matchValue, int *matchX, int *matchY,
					   		  unsigned char *inputPixels, int inputWidth, int inputHeight,
					   		  unsigned char *templatePixels, int templateWidth, int templateHeight) {
	int searchWidth = inputWidth - templateWidth;
	int searchHeight = inputHeight - templateHeight;
	int i, j, x, y;
	int sadValue, N = templateWidth * templateHeight;
	unsigned char inputValue, templateValue;

	*matchValue = 0x7fffffff;
	for (y = 0; y <= searchWidth; y ++ ) {
		for (x = 0; x <= searchHeight; x ++ ) {
			sadValue = 0;
			for (j = 0; j < templateHeight; ++j) {
				for (i = 0; i < templateWidth; ++i ) {
					templateValue = templatePixels[j * templateWidth + i];
					inputValue = inputPixels[(y + j) * inputWidth + (x + i)];
					sadValue += abs(templateValue - inputValue);
				}
			}
			sadValue /= N;
			if (sadValue < *matchValue) {
				*matchValue = sadValue;
				*matchX = x;
				*matchY = y;
			}
		}
	}
}
