/*	mouseEventDemo.cxx -- mouseEventDemo example
 *	This example demonstrates mouse event handling
 *
 *		Copyright © 2012-NOW Srikanth Anantharam
 *		Created 2012 by Srikanth Anantharam
 *		Modified 02-Feb-2016 by Srikanth Anantharam
 */

#include "SDLW.hxx"

int main(int argc, char * args[]) {
	// Flag that controls when the app exits
	int quitApp = 0;
	// Structure that holds the data from keyboard, mouse and window events
	SDL_Event eventData;
	char string[100] = "Click Mouse";

	// Initialize the display by providing the width, the height, and the bit depth of the window
    sdlInit(640, 480, 0);

    // Load font displaying text specifying the font size
    TTF_Font * font = fontLoad(FONT_INCONSOLATA_BOLD, 20);
	textDisplay(font, 0, 0, COLOR_MAGENTA, string);

	// The main loop continues to execute as long as quitApp is equal to 0
    while (quitApp == 0) {
    	// Catch keyboard, mouse, and window events
        while ( SDL_PollEvent( &eventData ) ) {
            switch ( eventData.type ) {
                case ( SDL_QUIT ):
                	// Exit from app if the user closes the window
                    quitApp = 1;
                    break;
                case ( SDL_KEYDOWN ):
					switch ( eventData.key.keysym.sym ) {
						case ( SDLK_ESCAPE ):
                			// Exit from app if the user presses the Escape button on the keyboard
							quitApp = 1;
							break;
						case ( SDLK_q ):
	                		// Exit from app if the user presses the "q" button on the keyboard
							quitApp = 1;
							break;
						default:
							break;
					}
                case ( SDL_MOUSEBUTTONDOWN ):
					switch ( eventData.button.button ) {
						case ( SDL_BUTTON_LEFT ):
                			// Print mouse coordinates
							printf("Mouse is at %d, %d\n", eventData.button.x, eventData.button.y);
                			// Erase previously displayed mouse coordinates by displaying in black
							textBlit(font, 0, 0, SDL_GetVideoSurface(), COLOR_BLACK, string); // For more colours check SDLW.hxx
							sprintf(string,"Mouse is at %d, %d", eventData.button.x, eventData.button.y);
                			// Display current mouse coordinates in default display colour
							textDisplay(font, 0, 0, COLOR_MAGENTA, string);
							break;
						default:
							break;
					}
                    break;
                default:
                    break;
            }
        }
    }

    // Always unload fonts that you have loaded
    fontFree(font);

    // Quit SDL
    sdlQuit();

	// Dont forget to return 0 as we have sucessfully executed
    return (0);
}
