/*	imageRgbToGrayDemo.cxx -- imageRgbToGrayDemo example
 *	This example demonstrates pixel level image manipulation
 *
 *		Copyright © 2012-NOW Srikanth Anantharam
 *		Created 2012 by Srikanth Anantharam
 *		Modified 02-Feb-2016 by Srikanth Anantharam
 */

#include "SDLW.hxx"

// Convert RGB image into Gray
void imageRGBtoGray(unsigned char *outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight);

// Convert RGBA image into Gray
void imageRGBAtoGray(unsigned char *outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight);

int main(int argc, char * args[]) {
	// Flag that controls when the app exits
	int quitApp = 0;
	// Structure that holds the data from keyboard, mouse and window events
	SDL_Event eventData;

	// Initialize the display by providing the width, the height, and the bit depth of the window
    sdlInit(0, 0, 0);

    // Load font displaying text
    TTF_Font * font = fontLoad(FONT_INCONSOLATA_BOLD, 20);

	// This is how you can load an image
        SDL_Surface *image = imageLoad("../data/images/lena.jpg");

	// This is how you can create an new image
	SDL_Surface *grayImage = imageCreate(image->w, image->h, 8);

	// Dont forget to lock the image before acessing its pixels
	imageLock(image);
	imageLock(grayImage);
	// Check the bits per pixel of the image and Obtain the gray image
	if ( image->format->BitsPerPixel == 24 ) {
		// Call RGB to Gray Conversion function
		imageRGBtoGray((unsigned char *)grayImage->pixels, (unsigned char *)image->pixels, image->w, image->h);
	} else if ( image->format->BitsPerPixel == 32 ) {
		// Call RGBA to Gray Conversion function
		imageRGBAtoGray((unsigned char *)grayImage->pixels, (unsigned char *)image->pixels, image->w, image->h);
	} else {
		printf("main:: error: unknown image format\n");
		goto end;
	}
	// Unlock the image after acessing its pixels
	imageUnlock(image);
	imageUnlock(grayImage);

	// Display Original Image along with some text
	imageDisplay(image, 0, 0);
	textDisplay(font, 0, image->h, COLOR_MAGENTA, "Original Image");

	// Display Grayscale Image on the right of Original Image along with some text
	imageDisplay(grayImage, image->w+20, 0);
	textDisplay(font, image->w+20, grayImage->h, COLOR_MAGENTA, "Grayscale Image");

	// The main loop continues to execute as long as quitApp is equal to 0
    while (quitApp == 0) {
    	// Catch keyboard, mouse, and window events
        while ( SDL_PollEvent( &eventData ) ) {
            switch ( eventData.type ) {
                case ( SDL_QUIT ):
                	// Exit from app if the user closes the window
                    quitApp = 1;
                    break;
                case ( SDL_KEYDOWN ):
					switch ( eventData.key.keysym.sym ) {
						case ( SDLK_ESCAPE ):
                			// Exit from app if the user presses the Escape button on the keyboard
							quitApp = 1;
							break;
						case ( SDLK_q ):
	                		// Exit from app if the user presses the "q" button on the keyboard
							quitApp = 1;
							break;
						default:
							break;
					}
                    break;
                default:
                    break;
            }
        }
    }

end:
    // Always unload any image that you create
	imageFree(image);
    imageFree(grayImage);

    // Aways unload fonts that you have loaded
    fontFree(font);

    // Quit SDL
    sdlQuit();

	// Dont forget to return 0 as we have sucessfully executed
    return (0);
}

// Convert RGB image into Gray
void imageRGBtoGray(unsigned char *outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight) {
	int i, j, pixelIndex;
	unsigned char r, g, b, gray;
	for ( j=0; j<imageHeight; ++j ) {
		for ( i=0; i<imageWidth; ++i ) {
			pixelIndex = i + j * imageWidth;
			r = inputPixels[pixelIndex * 3];
			g = inputPixels[pixelIndex * 3 + 1];
			b = inputPixels[pixelIndex * 3 + 2];
			gray = ( r * (int) (0.299f * 256) + g * (int) (0.587f * 256) + b * (int) (0.114f * 256) ) / 256;
			outputPixels[pixelIndex] = gray;
		}
	}
}

// Convert RGBA image into Gray
void imageRGBAtoGray(unsigned char *outputPixels, unsigned char * inputPixels, int imageWidth, int imageHeight) {
	int i, j, pixelIndex;
	unsigned char r, g, b, gray;
	for ( j=0; j<imageHeight; ++j ) {
		for ( i=0; i<imageWidth; ++i ) {
			pixelIndex = i + j * imageWidth;
			r = inputPixels[pixelIndex * 4];
			g = inputPixels[pixelIndex * 4 + 1];
			b = inputPixels[pixelIndex * 4 + 2];
			gray = ( r * (int) (0.299f * 256) + g * (int) (0.587f * 256) + b * (int) (0.114f * 256) ) / 256;
			outputPixels[pixelIndex] = gray;
		}
	}
}
